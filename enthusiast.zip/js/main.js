$(function(){
	/*SIMILAR SECTION SLIDER*/
	
	const similarProduct = new Swiper('.similar-swiper.swiper-container', {
		slidesPerView: 4,
		spaceBetween: 20,
//		autoplay: true,
		loop: true,
		navigation: {
			nextEl: '.swiper-button-next',
			prevEl: '.swiper-button-prev',
		},
		breakpoints: {
			450: {
				slidesPerView: 1,
				spaceBetween: 20
			},
			768: {
				slidesPerView: 2,
				spaceBetween: 20
			},
			992: {
				slidesPerView: 3,
				spaceBetween: 20
			}
		}
	});
	
	/*END SIMILAR SECTION SLIDER*/
	
	
	
	/*PRODUCT SLIDER*/
	
	var galleryThumbs = new Swiper('#product-thumbnail', {
      spaceBetween: 10,
			direction: 'vertical',
      slidesPerView: 4,
      freeMode: false,
       breakpoints: {
          767: {
            slidesPerView: 4,
            spaceBetween: 7,
          }
      },
      watchSlidesVisibility: true,
      watchSlidesProgress: true,
    });
    var galleryTop = new Swiper('#product-gallery', {
      loop: true,
      spaceBetween: 10,
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      thumbs: {
        swiper: galleryThumbs
      }

    });
	
	
	/*END PRODUCT SLIDER*/
	
	
	
	/*PRODUCT TAB*/
	
	$('.goto-contents .goto-contens-items').fadeOut(0);
	$('.goto-contents .goto-contens-items').eq(0).fadeIn();
	
	
	$('.goto .goto-items').on('click', function(){
		$('.goto .goto-items').removeClass('active');
		$(this).addClass('active');
		$('.goto-contents .goto-contens-items').fadeOut(0);
		$('.goto-contents .goto-contens-items').eq($(this).index()).fadeIn();
	})
	
	/*END PRODUCT TAB*/
	
	/*HEADER HAMBURGER MENU*/

	$('#hamburger, .mobile-closer, .header-helper').on('click', function(){
		$('.header-for-mobile, .header-helper').toggleClass('opened');
		$('html, body').toggleClass('overflowed');
	})
	
	$('.header-search .header-search-button, .header-search .cancel-form').on('click', function(){
		$('.header-search form').toggleClass('opened');
		$('.header-search form input').val('');
	})
	
	/*END HEADER HAMBURGER MENU*/
	
})